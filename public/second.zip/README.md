
  # Build this app

  This is a code bundle for Build this app. The original project is available at https://www.figma.com/design/lEjVaZ2rlFS9cBLUCJjn7C/Build-this-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  